"""
document_processor.py
─────────────────────
Handles all document ingestion:
  1. Parse PDF or TXT
  2. Split into overlapping chunks
  3. Generate embeddings
  4. Store in ChromaDB vector database
"""

import os
import hashlib
import chromadb
from pypdf import PdfReader
from sentence_transformers import SentenceTransformer


# ── constants ──────────────────────────────────────────────────────────────────
CHUNK_SIZE    = 512    # words per chunk
CHUNK_OVERLAP = 60     # words shared between adjacent chunks
EMBED_MODEL   = "all-MiniLM-L6-v2"
CHROMA_PATH   = "./chroma_db"


# ── singleton helpers ──────────────────────────────────────────────────────────
_embed_model = None
_chroma_client = None

def get_embed_model() -> SentenceTransformer:
    global _embed_model
    if _embed_model is None:
        _embed_model = SentenceTransformer(EMBED_MODEL)
    return _embed_model


def get_chroma_client() -> chromadb.PersistentClient:
    global _chroma_client
    if _chroma_client is None:
        os.makedirs(CHROMA_PATH, exist_ok=True)
        _chroma_client = chromadb.PersistentClient(path=CHROMA_PATH)
    return _chroma_client


# ── parsing ────────────────────────────────────────────────────────────────────
def parse_pdf(file_bytes: bytes) -> str:
    """Extract raw text from a PDF byte stream."""
    import io
    reader = PdfReader(io.BytesIO(file_bytes))
    pages = []
    for i, page in enumerate(reader.pages):
        text = page.extract_text()
        if text and text.strip():
            pages.append(f"[Page {i + 1}]\n{text.strip()}")
    return "\n\n".join(pages)


def parse_txt(file_bytes: bytes) -> str:
    """Decode a plain-text byte stream."""
    return file_bytes.decode("utf-8", errors="ignore")


def parse_document(file_bytes: bytes, file_name: str) -> str:
    """Route to the correct parser based on file extension."""
    ext = file_name.rsplit(".", 1)[-1].lower()
    if ext == "pdf":
        return parse_pdf(file_bytes)
    elif ext == "txt":
        return parse_txt(file_bytes)
    else:
        raise ValueError(f"Unsupported file type: .{ext}")


# ── chunking ───────────────────────────────────────────────────────────────────
def split_text(text: str,
               chunk_size: int = CHUNK_SIZE,
               overlap: int    = CHUNK_OVERLAP) -> list[str]:
    """
    Sliding-window word-level chunker with overlap.
    Overlap prevents information loss at chunk boundaries.
    """
    words  = text.split()
    chunks = []
    start  = 0

    while start < len(words):
        end   = min(start + chunk_size, len(words))
        chunk = " ".join(words[start:end])
        if chunk.strip():
            chunks.append(chunk)
        if end == len(words):
            break
        start = end - overlap          # slide back by overlap amount

    return chunks


# ── embedding + storage ────────────────────────────────────────────────────────
def doc_collection_name(file_name: str) -> str:
    """
    ChromaDB collection names must be 3-63 chars,
    alphanumeric + hyphens only.
    """
    safe = "".join(c if c.isalnum() else "-" for c in file_name.lower())
    safe = safe.strip("-")[:50]
    # append short hash so duplicate names never collide
    h = hashlib.md5(file_name.encode()).hexdigest()[:8]
    return f"{safe}-{h}"


def ingest_document(file_bytes: bytes,
                    file_name: str) -> dict:
    """
    Full ingestion pipeline:
      parse → chunk → embed → store
    Returns a summary dict for the UI.
    """
    # 1. parse
    raw_text = parse_document(file_bytes, file_name)
    if not raw_text.strip():
        raise ValueError("Could not extract any text from the document.")

    # 2. chunk
    chunks = split_text(raw_text)
    if not chunks:
        raise ValueError("Document produced no text chunks.")

    # 3. embed
    model      = get_embed_model()
    embeddings = model.encode(chunks, show_progress_bar=False).tolist()

    # 4. store
    client     = get_chroma_client()
    col_name   = doc_collection_name(file_name)

    # delete old collection for same file so re-upload works cleanly
    try:
        client.delete_collection(col_name)
    except Exception:
        pass

    collection = client.create_collection(
        name     = col_name,
        metadata = {"file_name": file_name}
    )

    ids = [f"chunk-{i}" for i in range(len(chunks))]
    collection.add(
        ids        = ids,
        embeddings = embeddings,
        documents  = chunks,
        metadatas  = [{"chunk_index": i, "file_name": file_name}
                      for i in range(len(chunks))]
    )

    return {
        "collection_name": col_name,
        "file_name"      : file_name,
        "total_chars"    : len(raw_text),
        "total_chunks"   : len(chunks),
        "chunk_size"     : CHUNK_SIZE,
        "overlap"        : CHUNK_OVERLAP,
        "embed_model"    : EMBED_MODEL,
    }


# ── retrieval ──────────────────────────────────────────────────────────────────
def retrieve_chunks(query          : str,
                    collection_name: str,
                    top_k          : int = 4) -> list[dict]:
    """
    Semantic search: convert query to embedding,
    find the top-k most similar chunks.
    Returns list of {text, chunk_index, score}.
    """
    model          = get_embed_model()
    query_embedding = model.encode(query).tolist()

    client     = get_chroma_client()
    collection = client.get_collection(collection_name)

    results = collection.query(
        query_embeddings = [query_embedding],
        n_results        = top_k,
        include          = ["documents", "metadatas", "distances"]
    )

    chunks = []
    for doc, meta, dist in zip(
        results["documents"][0],
        results["metadatas"][0],
        results["distances"][0]
    ):
        chunks.append({
            "text"       : doc,
            "chunk_index": meta.get("chunk_index", 0),
            "score"      : round(1 - dist, 3)   # cosine similarity
        })

    return chunks
