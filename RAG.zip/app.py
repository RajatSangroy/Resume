"""
app.py
──────
Insurance Document Q&A — Streamlit Application

RAG pipeline:
  Upload PDF/TXT → parse → chunk → embed → ChromaDB
  User question  → embed → semantic search → top-k chunks
  chunks + question → Groq LLM → streamed answer
"""

import streamlit as st
from document_processor import ingest_document, retrieve_chunks
from chat_engine import stream_chat


# ══════════════════════════════════════════════════════════════════════════════
# PAGE CONFIG
# ══════════════════════════════════════════════════════════════════════════════
st.set_page_config(
    page_title = "Insurance Policy Analyst",
    page_icon  = "🛡️",
    layout     = "wide",
)


# ══════════════════════════════════════════════════════════════════════════════
# CUSTOM CSS
# ══════════════════════════════════════════════════════════════════════════════
st.markdown("""
<style>
/* ── global palette ── */
:root {
    --navy:   #0d1b2a;
    --slate:  #1b2d43;
    --steel:  #263d56;
    --accent: #2a7de1;
    --gold:   #e8a020;
    --text:   #e4eaf2;
    --muted:  #7a93ad;
    --border: #1e3248;
    --green:  #22c55e;
    --red:    #ef4444;
}

/* ── body ── */
.stApp { background: var(--navy); color: var(--text); }

/* ── header strip ── */
.app-header {
    background: linear-gradient(135deg, #0d1b2a 0%, #1a3050 100%);
    border-bottom: 2px solid var(--accent);
    padding: 20px 28px 16px;
    margin: -1rem -1rem 1.5rem;
    display: flex;
    align-items: center;
    gap: 14px;
}
.app-header .shield { font-size: 36px; line-height: 1; }
.app-header h1 {
    font-size: 22px;
    font-weight: 700;
    color: var(--text);
    margin: 0;
    letter-spacing: -0.3px;
}
.app-header p {
    font-size: 13px;
    color: var(--muted);
    margin: 2px 0 0;
}

/* ── upload zone card ── */
.upload-card {
    background: var(--slate);
    border: 1px dashed var(--steel);
    border-radius: 12px;
    padding: 24px;
    text-align: center;
    transition: border-color 0.2s;
}

/* ── doc info banner ── */
.doc-banner {
    background: var(--slate);
    border: 1px solid var(--border);
    border-left: 4px solid var(--accent);
    border-radius: 8px;
    padding: 14px 18px;
    margin-bottom: 16px;
}
.doc-banner strong { color: var(--accent); }
.doc-meta {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
    margin-top: 8px;
}
.doc-meta span {
    font-size: 12px;
    color: var(--muted);
    background: var(--steel);
    padding: 3px 10px;
    border-radius: 999px;
}

/* ── chat messages ── */
.chat-user {
    background: var(--steel);
    border: 1px solid #2a4060;
    border-radius: 12px 12px 4px 12px;
    padding: 12px 16px;
    margin: 8px 0 8px 15%;
    font-size: 14px;
    line-height: 1.6;
}
.chat-assistant {
    background: #0e2340;
    border: 1px solid var(--accent);
    border-radius: 4px 12px 12px 12px;
    padding: 14px 16px;
    margin: 8px 15% 8px 0;
    font-size: 14px;
    line-height: 1.7;
}
.chat-role {
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.6px;
    margin-bottom: 6px;
    text-transform: uppercase;
}
.chat-user .chat-role   { color: var(--gold); }
.chat-assistant .chat-role { color: var(--accent); }

/* ── source chunks expander ── */
.source-header {
    font-size: 11px;
    color: var(--muted);
    margin-top: 10px;
    padding-top: 8px;
    border-top: 1px solid var(--border);
}
.source-chunk {
    background: var(--slate);
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 10px 12px;
    font-size: 12px;
    color: var(--muted);
    margin-top: 6px;
    line-height: 1.6;
}
.source-score {
    font-size: 11px;
    color: var(--accent);
    margin-bottom: 4px;
    font-weight: 600;
}

/* ── suggestion chips ── */
.chip-row {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin: 12px 0 4px;
}
.chip {
    background: var(--slate);
    border: 1px solid var(--steel);
    border-radius: 999px;
    padding: 6px 14px;
    font-size: 12px;
    color: var(--muted);
    cursor: pointer;
    transition: background 0.15s, color 0.15s;
}
.chip:hover { background: var(--steel); color: var(--text); }

/* ── status pills ── */
.pill-ready {
    display: inline-block;
    background: #052e1a;
    color: var(--green);
    border: 1px solid #14532d;
    border-radius: 999px;
    padding: 3px 12px;
    font-size: 12px;
    font-weight: 600;
}
.pill-waiting {
    display: inline-block;
    background: #1e1200;
    color: var(--gold);
    border: 1px solid #6b3a00;
    border-radius: 999px;
    padding: 3px 12px;
    font-size: 12px;
    font-weight: 600;
}

/* ── sidebar ── */
section[data-testid="stSidebar"] {
    background: var(--slate) !important;
    border-right: 1px solid var(--border);
}
section[data-testid="stSidebar"] * { color: var(--text) !important; }

/* ── input box ── */
.stTextInput input, .stChatInput textarea {
    background: var(--slate) !important;
    border: 1px solid var(--steel) !important;
    color: var(--text) !important;
    border-radius: 8px !important;
}
.stChatInput textarea:focus {
    border-color: var(--accent) !important;
    box-shadow: 0 0 0 2px rgba(42,125,225,0.25) !important;
}

/* ── streamlit button override ── */
.stButton > button {
    background: var(--accent);
    color: white;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    transition: opacity 0.15s;
}
.stButton > button:hover { opacity: 0.85; }

/* ── divider ── */
hr { border-color: var(--border) !important; }
</style>
""", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# SESSION STATE INITIALISATION
# ══════════════════════════════════════════════════════════════════════════════
if "messages"         not in st.session_state: st.session_state.messages         = []
if "collection_name"  not in st.session_state: st.session_state.collection_name  = None
if "doc_info"         not in st.session_state: st.session_state.doc_info         = None
if "ingested_file"    not in st.session_state: st.session_state.ingested_file    = None
if "suggested_q"      not in st.session_state: st.session_state.suggested_q      = None


# ══════════════════════════════════════════════════════════════════════════════
# HEADER
# ══════════════════════════════════════════════════════════════════════════════
st.markdown("""
<div class="app-header">
  <div class="shield">🛡️</div>
  <div>
    <h1>Insurance Policy Analyst</h1>
    <p>Upload a policy document and ask questions about claims &amp; coverage</p>
  </div>
</div>
""", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR — document upload + settings
# ══════════════════════════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown("### 📄 Document")

    uploaded_file = st.file_uploader(
        "Upload your insurance document",
        type        = ["pdf", "txt"],
        help        = "Supports PDF and plain text files. "
                      "Re-upload to switch documents.",
        label_visibility = "collapsed",
    )

    # ── ingest on new upload ──────────────────────────────────────────────
    if uploaded_file is not None:
        is_new = (st.session_state.ingested_file != uploaded_file.name)

        if is_new:
            with st.spinner("Processing document…"):
                try:
                    file_bytes = uploaded_file.read()
                    doc_info   = ingest_document(file_bytes, uploaded_file.name)

                    st.session_state.collection_name = doc_info["collection_name"]
                    st.session_state.doc_info        = doc_info
                    st.session_state.ingested_file   = uploaded_file.name
                    st.session_state.messages        = []   # fresh chat
                    st.session_state.suggested_q     = None

                    st.success("Document ready!", icon="✅")

                except Exception as e:
                    st.error(f"Failed to process document:\n{e}")
                    st.session_state.collection_name = None
                    st.session_state.doc_info        = None

    # ── doc summary ───────────────────────────────────────────────────────
    if st.session_state.doc_info:
        info = st.session_state.doc_info
        st.markdown("---")
        st.markdown("**Document loaded**")
        st.markdown(f"📎 `{info['file_name']}`")
        col1, col2 = st.columns(2)
        col1.metric("Chunks", f"{info['total_chunks']:,}")
        col2.metric("Characters", f"{info['total_chars']:,}")
        st.caption(f"Embed model: {info['embed_model']}")

    st.markdown("---")

    # ── retrieval settings ────────────────────────────────────────────────
    st.markdown("### ⚙️ Settings")
    top_k = st.slider(
        "Chunks to retrieve",
        min_value = 2,
        max_value = 8,
        value     = 4,
        help      = "How many document excerpts to include as context. "
                    "Higher = more context but more tokens."
    )
    show_sources = st.toggle("Show source excerpts", value=True)

    st.markdown("---")

    # ── clear chat ────────────────────────────────────────────────────────
    if st.button("🗑️ Clear conversation", use_container_width=True):
        st.session_state.messages    = []
        st.session_state.suggested_q = None
        st.rerun()

    st.markdown("---")
    st.caption("P&C Insurance Document Analyst · Powered by Groq + LLaMA 3")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN AREA — chat interface
# ══════════════════════════════════════════════════════════════════════════════

# ── no document uploaded yet ──────────────────────────────────────────────────
if not st.session_state.collection_name:
    st.markdown("""
    <div class="upload-card">
        <div style="font-size:48px;margin-bottom:12px">📋</div>
        <h3 style="color:#e4eaf2;margin:0 0 8px">No document loaded</h3>
        <p style="color:#7a93ad;margin:0;font-size:14px">
            Upload an insurance policy PDF or TXT file from the sidebar<br>
            to start asking questions about claims and coverage.
        </p>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("#### What you can ask once a document is loaded")
    examples = [
        "What is the deductible for water damage claims?",
        "Is jewellery covered under this policy?",
        "How do I file a claim for storm damage?",
        "What are the main exclusions in this policy?",
        "What is the maximum coverage limit for personal property?",
        "How long do I have to report a claim after an incident?",
        "Does this policy cover loss of use / additional living expenses?",
        "What documents do I need to submit with a claim?",
    ]
    cols = st.columns(2)
    for i, ex in enumerate(examples):
        cols[i % 2].markdown(f"- _{ex}_")

    st.stop()


# ── document banner ───────────────────────────────────────────────────────────
info = st.session_state.doc_info
st.markdown(f"""
<div class="doc-banner">
    <strong>📎 {info['file_name']}</strong>
    &nbsp;<span class="pill-ready">Ready</span>
    <div class="doc-meta">
        <span>{info['total_chunks']:,} chunks</span>
        <span>{info['total_chars']:,} characters</span>
        <span>Top-{top_k} retrieval</span>
    </div>
</div>
""", unsafe_allow_html=True)


# ── suggested opening questions ────────────────────────────────────────────────
SUGGESTIONS = [
    "What does this policy cover?",
    "What are the main exclusions?",
    "How do I file a claim?",
    "What are the coverage limits?",
    "What is the deductible?",
    "Is there coverage for water damage?",
]

if not st.session_state.messages:
    st.markdown("**Suggested questions — click to ask:**")
    cols = st.columns(3)
    for i, s in enumerate(SUGGESTIONS):
        if cols[i % 3].button(s, key=f"sug_{i}", use_container_width=True):
            st.session_state.suggested_q = s
            st.rerun()


# ── render existing conversation ──────────────────────────────────────────────
for msg in st.session_state.messages:
    role    = msg["role"]
    content = msg["content"]
    chunks  = msg.get("chunks", [])

    if role == "user":
        st.markdown(f"""
        <div class="chat-user">
            <div class="chat-role">You</div>
            {content}
        </div>
        """, unsafe_allow_html=True)

    else:
        # assistant message
        st.markdown(f"""
        <div class="chat-assistant">
            <div class="chat-role">🛡️ Policy Analyst</div>
            {content.replace(chr(10), "<br>")}
        </div>
        """, unsafe_allow_html=True)

        # optional source excerpt expander
        if show_sources and chunks:
            with st.expander(f"📄 {len(chunks)} source excerpt(s) used", expanded=False):
                for i, c in enumerate(chunks, 1):
                    st.markdown(f"""
                    <div class="source-chunk">
                        <div class="source-score">Excerpt {i} · Relevance {c['score']:.0%}</div>
                        {c['text'][:400]}{'…' if len(c['text']) > 400 else ''}
                    </div>
                    """, unsafe_allow_html=True)


# ── handle suggested question click ──────────────────────────────────────────
user_input = None
if st.session_state.suggested_q:
    user_input = st.session_state.suggested_q
    st.session_state.suggested_q = None


# ── chat input ────────────────────────────────────────────────────────────────
chat_input = st.chat_input(
    "Ask about claims, coverage, exclusions, deductibles…",
    disabled = not st.session_state.collection_name
)

if chat_input:
    user_input = chat_input


# ══════════════════════════════════════════════════════════════════════════════
# PROCESS USER MESSAGE
# ══════════════════════════════════════════════════════════════════════════════
if user_input and st.session_state.collection_name:

    # render user bubble immediately
    st.markdown(f"""
    <div class="chat-user">
        <div class="chat-role">You</div>
        {user_input}
    </div>
    """, unsafe_allow_html=True)

    # add to history
    st.session_state.messages.append({"role": "user", "content": user_input})

    # ── retrieve relevant chunks ──────────────────────────────────────────
    with st.spinner("Searching document…"):
        try:
            chunks = retrieve_chunks(
                query           = user_input,
                collection_name = st.session_state.collection_name,
                top_k           = top_k,
            )
        except Exception as e:
            st.error(f"Retrieval error: {e}")
            st.stop()

    # ── build conversation history for LLM (without chunk metadata) ───────
    history_for_llm = [
        {"role": m["role"], "content": m["content"]}
        for m in st.session_state.messages[:-1]   # exclude current user msg
    ]

    # ── stream response ───────────────────────────────────────────────────
    st.markdown("""
    <div class="chat-assistant" id="streaming-response">
        <div class="chat-role">🛡️ Policy Analyst</div>
    """, unsafe_allow_html=True)

    response_placeholder = st.empty()
    full_response        = ""

    try:
        for token in stream_chat(
            user_question        = user_input,
            retrieved_chunks     = chunks,
            conversation_history = history_for_llm,
        ):
            full_response += token
            response_placeholder.markdown(full_response + "▌")

        response_placeholder.markdown(full_response)

    except Exception as e:
        full_response = f"⚠️ Error calling LLM: {e}"
        response_placeholder.error(full_response)

    st.markdown("</div>", unsafe_allow_html=True)

    # ── save assistant message with source chunks ─────────────────────────
    st.session_state.messages.append({
        "role"   : "assistant",
        "content": full_response,
        "chunks" : chunks,
    })

    # ── show sources immediately after streaming ───────────────────────────
    if show_sources and chunks:
        with st.expander(f"📄 {len(chunks)} source excerpt(s) used", expanded=False):
            for i, c in enumerate(chunks, 1):
                st.markdown(f"""
                <div class="source-chunk">
                    <div class="source-score">Excerpt {i} · Relevance {c['score']:.0%}</div>
                    {c['text'][:400]}{'…' if len(c['text']) > 400 else ''}
                </div>
                """, unsafe_allow_html=True)

    st.rerun()
