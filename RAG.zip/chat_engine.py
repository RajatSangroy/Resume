"""
chat_engine.py
──────────────
Handles all LLM interaction:
  - Builds the RAG prompt from retrieved chunks
  - Calls Groq API with full conversation history
  - Returns streamed or complete responses
"""

import os
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

# ── constants ──────────────────────────────────────────────────────────────────
MODEL       = "llama3-70b-8192"
TEMPERATURE = 0.2        # low = factual, grounded answers
MAX_TOKENS  = 1024


# ── system prompt ──────────────────────────────────────────────────────────────
SYSTEM_PROMPT = """You are an expert P&C (Property and Casualty) Insurance \
document analyst specialising in claims and coverage interpretation.

Your role:
- Answer questions about the insurance document the user has uploaded
- Focus specifically on claims processes, coverage terms, exclusions, limits, \
deductibles, and policy conditions
- Always ground your answers in the document context provided
- If a specific detail is not in the provided context, say so clearly — \
never fabricate policy terms or coverage amounts
- Use plain English; avoid unnecessary jargon unless the document itself uses it
- When quoting or referencing specific sections, indicate where the information \
comes from (e.g. "According to the document...")
- If the question is outside the scope of the uploaded document, politely \
redirect the user

Tone: professional, precise, helpful — like a knowledgeable claims advisor \
explaining policy details to a policyholder."""


# ── client factory ─────────────────────────────────────────────────────────────
def get_groq_client() -> Groq:
    api_key = os.environ.get("GROQ_API_KEY")
    if not api_key:
        raise EnvironmentError(
            "GROQ_API_KEY not found. "
            "Please add it to your .env file."
        )
    return Groq(api_key=api_key)


# ── prompt builder ─────────────────────────────────────────────────────────────
def build_rag_prompt(user_question: str,
                     retrieved_chunks: list[dict]) -> str:
    """
    Inject retrieved document chunks into the user message
    so the LLM answers from the document, not from training data.
    """
    if not retrieved_chunks:
        return user_question

    context_parts = []
    for i, chunk in enumerate(retrieved_chunks, 1):
        score = chunk.get("score", 0)
        context_parts.append(
            f"[Excerpt {i} — relevance {score:.0%}]\n{chunk['text']}"
        )

    context_block = "\n\n---\n\n".join(context_parts)

    return f"""Use the following excerpts from the insurance document to \
answer the question. Base your answer strictly on these excerpts. \
If the answer is not found here, say so.

═══ DOCUMENT EXCERPTS ═══
{context_block}
═══════════════════════════

Question: {user_question}"""


# ── main chat function ─────────────────────────────────────────────────────────
def chat(user_question     : str,
         retrieved_chunks  : list[dict],
         conversation_history: list[dict]) -> str:
    """
    Send the RAG-augmented question to Groq and return the full response.

    conversation_history: list of {"role": "user"|"assistant", "content": str}
    """
    client = get_groq_client()

    # build the augmented user message
    augmented_question = build_rag_prompt(user_question, retrieved_chunks)

    # assemble messages: system + history + new user turn
    messages = (
        [{"role": "system", "content": SYSTEM_PROMPT}]
        + conversation_history
        + [{"role": "user", "content": augmented_question}]
    )

    response = client.chat.completions.create(
        model       = MODEL,
        messages    = messages,
        temperature = TEMPERATURE,
        max_tokens  = MAX_TOKENS,
    )

    return response.choices[0].message.content


def stream_chat(user_question      : str,
                retrieved_chunks   : list[dict],
                conversation_history: list[dict]):
    """
    Streaming version — yields text tokens as they arrive.
    Use with st.write_stream() in Streamlit.
    """
    client = get_groq_client()

    augmented_question = build_rag_prompt(user_question, retrieved_chunks)

    messages = (
        [{"role": "system", "content": SYSTEM_PROMPT}]
        + conversation_history
        + [{"role": "user", "content": augmented_question}]
    )

    stream = client.chat.completions.create(
        model       = MODEL,
        messages    = messages,
        temperature = TEMPERATURE,
        max_tokens  = MAX_TOKENS,
        stream      = True,
    )

    for chunk in stream:
        delta = chunk.choices[0].delta.content
        if delta:
            yield delta
