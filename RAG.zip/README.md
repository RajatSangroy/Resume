# 🛡️ Insurance Policy Analyst

A RAG-powered Streamlit application for analysing P&C insurance documents.
Upload any policy PDF or TXT file and ask questions about **claims, coverage,
exclusions, deductibles and more** — grounded entirely in the document you
provide.

---

## What it does

```
Upload document
      ↓
Parse → Chunk (512 words, 60-word overlap) → Embed (MiniLM) → ChromaDB
      ↓
User asks question
      ↓
Question embedded → Semantic search → Top-4 chunks retrieved
      ↓
Chunks + question → Groq LLaMA 3 70B → Streamed answer
      ↓
Sources shown alongside answer
```

---

## Project structure

```
insurance_rag_app/
│
├── app.py                  ← Streamlit UI (main entry point)
├── document_processor.py   ← Parse, chunk, embed, store, retrieve
├── chat_engine.py          ← Groq LLM calls + RAG prompt builder
│
├── requirements.txt        ← Python dependencies
├── .env.example            ← API key template
├── .gitignore
└── README.md
```

---

## Setup — step by step

### 1. Clone or copy the project folder

```bash
cd insurance_rag_app
```

### 2. Create and activate a virtual environment

```bash
# Mac / Linux
python3 -m venv venv
source venv/bin/activate

# Windows
python -m venv venv
venv\Scripts\activate
```

### 3. Install dependencies

```bash
pip3 install -r requirements.txt
```

> Note: `sentence-transformers` downloads the MiniLM embedding model (~90 MB)
> on first run. This is a one-time download.

### 4. Add your Groq API key

```bash
cp .env.example .env
```

Open `.env` and replace the placeholder:

```
GROQ_API_KEY=your-actual-groq-api-key-here
```

Get a free key at: https://console.groq.com

### 5. Run the app

```bash
streamlit run app.py
```

The app opens at **http://localhost:8501**

---

## How to use

1. **Upload** a PDF or TXT insurance document using the sidebar
2. Wait for the green **"Document ready!"** confirmation
3. Click a **suggested question** or type your own in the chat box
4. The analyst answers from the document, with **source excerpts** shown below
   each answer
5. Continue the conversation — the app maintains full **conversation history**
6. **Clear conversation** button resets the chat (document stays loaded)
7. **Re-upload** a new file to switch documents at any time

---

## Settings (sidebar)

| Setting | Description |
|---|---|
| Chunks to retrieve | How many document excerpts feed into each answer (2–8) |
| Show source excerpts | Toggle visibility of retrieved chunks below answers |

---

## RAG pipeline details

| Component | Choice | Reason |
|---|---|---|
| Parser | PyPDF | Fast, reliable PDF text extraction |
| Chunker | Word-level sliding window | 512 words, 60-word overlap — prevents boundary cutoff |
| Embedding model | all-MiniLM-L6-v2 | Fast, good quality, free, runs locally |
| Vector database | ChromaDB (local) | Zero config, persists to ./chroma_db |
| LLM | LLaMA 3 70B via Groq | High quality, fast inference, generous free tier |
| Temperature | 0.2 | Low = grounded, factual answers |
| Retrieval | Top-4 cosine similarity | Balances context richness vs token cost |

---

## Supported document types

- **PDF** — policy documents, endorsements, declarations pages
- **TXT** — plain text policy extracts

---

## Example questions

- *What is the deductible for water damage claims?*
- *Is jewellery covered under this policy?*
- *How do I file a claim for storm damage?*
- *What are the main exclusions?*
- *What is the maximum coverage limit for personal property?*
- *How long do I have to report a claim after an incident?*
- *Does this policy cover additional living expenses?*
- *What documents do I need to submit with a claim?*
