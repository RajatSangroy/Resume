@echo off
echo ============================================
echo  Insurance Policy Analyst - Starting App
echo ============================================
echo.

REM Activate virtual environment
call venv\Scripts\activate.bat
if errorlevel 1 (
    echo ERROR: Virtual environment not found.
    echo Please run setup.bat first.
    pause
    exit /b 1
)

REM Check .env has been configured
findstr /c:"your-groq-api-key-here" .env >nul 2>&1
if not errorlevel 1 (
    echo WARNING: You have not set your GROQ_API_KEY in the .env file.
    echo Please open .env and replace the placeholder with your actual key.
    echo Get a free key at: https://console.groq.com
    echo.
    pause
)

echo Starting app...
echo Once started, open your browser and go to:
echo http://localhost:8501
echo.
echo Press Ctrl+C to stop the app.
echo.

python -m streamlit run app.py --server.port=8501 --server.address=localhost
pause
