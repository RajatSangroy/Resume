"""
chat_engine.py
──────────────
Manages all LLM interaction for the Insurance Policy Analyst.

Responsibilities:
  - Build the RAG prompt (inject retrieved chunks into user message)
  - Maintain conversation history format for Groq API
  - Stream tokens back to Streamlit UI
  - Apply insurance-specific system prompt
"""

import os
from groq import Groq
from dotenv import load_dotenv

# Load .env file from the project directory
load_dotenv()


# ── Configuration ──────────────────────────────────────────────────────────────
MODEL       = "llama3-70b-8192"   # powerful, fast, generous free tier on Groq
TEMPERATURE = 0.1                 # very low = grounded, factual, consistent
MAX_TOKENS  = 1024                # enough for detailed answers


# ── Insurance-Specific System Prompt ──────────────────────────────────────────
SYSTEM_PROMPT = """You are an expert P&C (Property and Casualty) Insurance \
document analyst with deep knowledge of:
- Property insurance claims processes
- Coverage terms, conditions and exclusions
- Deductibles, limits and sub-limits
- Policy endorsements and riders
- Claim filing procedures and timelines
- Coverage disputes and resolution

Your job:
1. Answer questions ONLY based on the document excerpts provided
2. Be precise — quote specific terms, limits and conditions from the document
3. If a question cannot be answered from the provided excerpts, say clearly:
   "I cannot find that specific information in the provided document sections."
4. Never invent coverage amounts, exclusions or policy terms
5. When referencing information say "According to the document..." or 
   "The policy states..."
6. Use plain English — explain insurance jargon in simple terms
7. If asked about something outside insurance scope, politely redirect

Format your answers clearly:
- Use short paragraphs for explanations
- Use bullet points for lists of exclusions, requirements or steps
- Bold important terms, limits or deadlines"""


# ── Groq Client ────────────────────────────────────────────────────────────────
def get_client() -> Groq:
    """Create Groq client using API key from .env file."""
    api_key = os.environ.get("GROQ_API_KEY", "").strip()
    if not api_key or api_key == "your-groq-api-key-here":
        raise EnvironmentError(
            "GROQ_API_KEY is missing or not set.\n"
            "Please open the .env file and add your Groq API key.\n"
            "Get a free key at: https://console.groq.com"
        )
    return Groq(api_key=api_key)


# ── RAG Prompt Builder ─────────────────────────────────────────────────────────
def build_rag_prompt(user_question: str, chunks: list) -> str:
    """
    Inject retrieved document chunks into the user message.

    This is the RAG augmentation step — the LLM answers from
    the document, not from its training data.

    Structure:
        [Document excerpts section]
        ---
        [User question]
    """
    if not chunks:
        # No chunks retrieved — ask LLM to acknowledge it has no context
        return (
            f"{user_question}\n\n"
            "Note: No relevant document sections were found for this question. "
            "Please answer based on general insurance knowledge and clearly "
            "state that this information is not from the uploaded document."
        )

    # Build the context block from retrieved chunks
    excerpt_lines = []
    for i, chunk in enumerate(chunks, start=1):
        score = chunk.get("score", 0)
        excerpt_lines.append(
            f"--- Excerpt {i} (relevance: {score:.0%}) ---\n"
            f"{chunk['text']}"
        )

    context = "\n\n".join(excerpt_lines)

    return (
        "The following excerpts are from the insurance document the user "
        "uploaded. Use these excerpts to answer the question. "
        "Do not use information outside these excerpts.\n\n"
        f"{context}\n\n"
        "---\n\n"
        f"Question: {user_question}"
    )


# ── Streaming Chat ─────────────────────────────────────────────────────────────
def stream_response(
    user_question       : str,
    chunks              : list,
    conversation_history: list,
):
    """
    Stream LLM response tokens to the Streamlit UI.

    Args:
        user_question:        The raw user input string
        chunks:               Retrieved document chunks from semantic search
        conversation_history: Previous turns as list of role/content dicts
                              (excludes the current turn)

    Yields:
        str — individual tokens as they arrive from Groq
    """
    client = get_client()

    # Build the augmented prompt with document context
    augmented_prompt = build_rag_prompt(user_question, chunks)

    # Assemble full message list:
    # [system] + [previous turns] + [current user message with context]
    messages = (
        [{"role": "system", "content": SYSTEM_PROMPT}]
        + conversation_history
        + [{"role": "user", "content": augmented_prompt}]
    )

    # Stream from Groq
    stream = get_client().chat.completions.create(
        model       = MODEL,
        messages    = messages,
        temperature = TEMPERATURE,
        max_tokens  = MAX_TOKENS,
        stream      = True,
    )

    for chunk in stream:
        token = chunk.choices[0].delta.content
        if token is not None:
            yield token
