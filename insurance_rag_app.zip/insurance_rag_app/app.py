"""
app.py
──────
Insurance Policy Analyst — Main Streamlit Application

This file must be the entry point:
    python -m streamlit run app.py

Windows asyncio fix is applied at the very top before
any other imports to prevent the common Windows hang.
"""

# ── Windows Fix — MUST be first, before all other imports ─────────────────────
import sys
import asyncio

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

# ── Standard imports ───────────────────────────────────────────────────────────
import os
import streamlit as st
from dotenv import load_dotenv

# ── Project modules ────────────────────────────────────────────────────────────
from document_processor import ingest_document, retrieve_chunks
from chat_engine import stream_response

# Load environment variables from .env file
load_dotenv()


# ══════════════════════════════════════════════════════════════════════════════
# PAGE CONFIGURATION — must be the first Streamlit call
# ══════════════════════════════════════════════════════════════════════════════
st.set_page_config(
    page_title = "Insurance Policy Analyst",
    page_icon  = "🛡️",
    layout     = "wide",
    initial_sidebar_state = "expanded",
)


# ══════════════════════════════════════════════════════════════════════════════
# STYLING
# ══════════════════════════════════════════════════════════════════════════════
st.markdown("""
<style>

/* ── Base colours ── */
:root {
    --c-bg       : #0b1520;
    --c-surface  : #112030;
    --c-card     : #172840;
    --c-border   : #1e3a55;
    --c-accent   : #1d7bd4;
    --c-accent-lt: #4fa3e8;
    --c-gold     : #d4a017;
    --c-text     : #ddeeff;
    --c-muted    : #6a90b0;
    --c-green    : #22c55e;
    --c-green-bg : #052e16;
    --c-green-bd : #166534;
    --c-amber    : #f59e0b;
    --c-amber-bg : #1c1000;
    --c-amber-bd : #92400e;
}

/* ── App background ── */
.stApp {
    background-color: var(--c-bg);
    color: var(--c-text);
}

/* ── Top header bar ── */
.top-bar {
    background: linear-gradient(90deg, #0b1520 0%, #112a42 60%, #0b1520 100%);
    border-bottom: 2px solid var(--c-accent);
    padding: 18px 32px;
    margin: -1.5rem -1rem 1.5rem -1rem;
    display: flex;
    align-items: center;
    gap: 16px;
}
.top-bar-icon { font-size: 40px; flex-shrink: 0; }
.top-bar-title {
    font-size: 20px;
    font-weight: 700;
    color: var(--c-text);
    margin: 0;
    letter-spacing: -0.2px;
}
.top-bar-sub {
    font-size: 12px;
    color: var(--c-muted);
    margin: 3px 0 0;
}

/* ── Welcome / no-doc screen ── */
.welcome-box {
    background: var(--c-surface);
    border: 1px dashed var(--c-border);
    border-radius: 14px;
    padding: 40px 32px;
    text-align: center;
    margin-top: 16px;
}
.welcome-icon { font-size: 56px; margin-bottom: 16px; }
.welcome-title {
    font-size: 20px;
    font-weight: 600;
    color: var(--c-text);
    margin: 0 0 8px;
}
.welcome-sub {
    font-size: 14px;
    color: var(--c-muted);
    margin: 0;
    line-height: 1.6;
}

/* ── Document loaded banner ── */
.doc-banner {
    background: var(--c-surface);
    border: 1px solid var(--c-border);
    border-left: 4px solid var(--c-accent);
    border-radius: 10px;
    padding: 14px 18px;
    margin-bottom: 20px;
}
.doc-name { color: var(--c-accent-lt); font-weight: 600; font-size: 15px; }
.doc-pills {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-top: 8px;
}
.doc-pill {
    background: var(--c-card);
    color: var(--c-muted);
    border: 1px solid var(--c-border);
    border-radius: 999px;
    padding: 2px 12px;
    font-size: 12px;
}
.status-ready {
    background: var(--c-green-bg);
    color: var(--c-green);
    border: 1px solid var(--c-green-bd);
    border-radius: 999px;
    padding: 2px 12px;
    font-size: 12px;
    font-weight: 600;
    display: inline-block;
}

/* ── Chat bubbles ── */
.bubble-user {
    background: var(--c-card);
    border: 1px solid #234060;
    border-radius: 14px 14px 4px 14px;
    padding: 12px 16px;
    margin: 10px 0 10px 18%;
    font-size: 14px;
    line-height: 1.65;
    color: var(--c-text);
}
.bubble-bot {
    background: #0d2240;
    border: 1px solid var(--c-accent);
    border-radius: 4px 14px 14px 14px;
    padding: 14px 18px;
    margin: 10px 18% 10px 0;
    font-size: 14px;
    line-height: 1.75;
    color: var(--c-text);
}
.bubble-label {
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 1px;
    text-transform: uppercase;
    margin-bottom: 7px;
}
.bubble-user .bubble-label  { color: var(--c-gold); }
.bubble-bot  .bubble-label  { color: var(--c-accent-lt); }

/* ── Source excerpt cards ── */
.src-card {
    background: var(--c-surface);
    border: 1px solid var(--c-border);
    border-radius: 8px;
    padding: 10px 14px;
    font-size: 12px;
    color: var(--c-muted);
    line-height: 1.6;
    margin-top: 8px;
}
.src-card-label {
    font-size: 11px;
    font-weight: 600;
    color: var(--c-accent-lt);
    margin-bottom: 5px;
}

/* ── Error / warning box ── */
.warn-box {
    background: var(--c-amber-bg);
    border: 1px solid var(--c-amber-bd);
    border-radius: 8px;
    padding: 12px 16px;
    color: var(--c-amber);
    font-size: 13px;
    margin-bottom: 16px;
}

/* ── Sidebar ── */
section[data-testid="stSidebar"] {
    background: var(--c-surface) !important;
    border-right: 1px solid var(--c-border) !important;
}
section[data-testid="stSidebar"] label,
section[data-testid="stSidebar"] p,
section[data-testid="stSidebar"] span,
section[data-testid="stSidebar"] div {
    color: var(--c-text) !important;
}

/* ── Chat input ── */
.stChatInput > div {
    background: var(--c-surface) !important;
    border: 1px solid var(--c-border) !important;
    border-radius: 10px !important;
}
.stChatInput textarea {
    color: var(--c-text) !important;
    background: transparent !important;
}

/* ── Streamlit buttons ── */
.stButton > button {
    background: var(--c-accent) !important;
    color: #fff !important;
    border: none !important;
    border-radius: 8px !important;
    font-weight: 600 !important;
    transition: opacity 0.15s !important;
}
.stButton > button:hover { opacity: 0.82 !important; }

/* ── Metrics ── */
[data-testid="stMetricValue"] {
    color: var(--c-accent-lt) !important;
    font-weight: 700 !important;
}

/* ── Divider ── */
hr { border-color: var(--c-border) !important; }

/* ── Scrollbar ── */
::-webkit-scrollbar { width: 6px; }
::-webkit-scrollbar-track { background: var(--c-bg); }
::-webkit-scrollbar-thumb { background: var(--c-border); border-radius: 3px; }

</style>
""", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# SESSION STATE — initialise all keys once
# ══════════════════════════════════════════════════════════════════════════════
defaults = {
    "messages"        : [],       # full conversation history
    "collection_name" : None,     # ChromaDB collection for current document
    "doc_info"        : None,     # document metadata dict
    "last_file_name"  : None,     # detect when user re-uploads
    "pending_question": None,     # question from suggestion buttons
}
for key, val in defaults.items():
    if key not in st.session_state:
        st.session_state[key] = val


# ══════════════════════════════════════════════════════════════════════════════
# TOP HEADER BAR
# ══════════════════════════════════════════════════════════════════════════════
st.markdown("""
<div class="top-bar">
    <div class="top-bar-icon">🛡️</div>
    <div>
        <div class="top-bar-title">Insurance Policy Analyst</div>
        <div class="top-bar-sub">
            Upload a P&amp;C insurance document · Ask about claims, coverage,
            exclusions and deductibles
        </div>
    </div>
</div>
""", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ══════════════════════════════════════════════════════════════════════════════
with st.sidebar:

    # ── API key check ─────────────────────────────────────────────────────
    api_key = os.environ.get("GROQ_API_KEY", "").strip()
    if not api_key or api_key == "your-groq-api-key-here":
        st.markdown("""
        <div class="warn-box">
            ⚠️ <strong>API key missing</strong><br>
            Open the <code>.env</code> file and add your
            <code>GROQ_API_KEY</code>.<br>
            Get a free key at
            <a href="https://console.groq.com" target="_blank">
            console.groq.com</a>
        </div>
        """, unsafe_allow_html=True)

    # ── File uploader ─────────────────────────────────────────────────────
    st.markdown("### 📄 Document")
    uploaded = st.file_uploader(
        "Upload insurance document",
        type             = ["pdf", "txt"],
        label_visibility = "collapsed",
        help             = "PDF or plain text insurance policy document",
    )

    # ── Ingest on new upload ──────────────────────────────────────────────
    if uploaded is not None:
        is_new_file = (st.session_state.last_file_name != uploaded.name)
        if is_new_file:
            with st.spinner("Reading and processing document…"):
                try:
                    raw_bytes = uploaded.read()
                    info      = ingest_document(raw_bytes, uploaded.name)

                    st.session_state.collection_name  = info["collection_name"]
                    st.session_state.doc_info         = info
                    st.session_state.last_file_name   = uploaded.name
                    st.session_state.messages         = []   # reset chat
                    st.session_state.pending_question = None

                    st.success("✅ Document ready!")

                except Exception as err:
                    st.error(f"Could not process document:\n\n{err}")
                    st.session_state.collection_name = None
                    st.session_state.doc_info        = None

    # ── Document stats ────────────────────────────────────────────────────
    if st.session_state.doc_info:
        info = st.session_state.doc_info
        st.markdown("---")
        st.markdown("**Loaded document**")
        st.code(info["file_name"], language=None)
        c1, c2 = st.columns(2)
        c1.metric("Chunks",      f"{info['total_chunks']:,}")
        c2.metric("Characters",  f"{info['total_chars']:,}")
        st.caption(f"Model: {info['embed_model']}")

    st.markdown("---")

    # ── Retrieval settings ────────────────────────────────────────────────
    st.markdown("### ⚙️ Settings")
    top_k = st.slider(
        "Chunks to retrieve per question",
        min_value = 2,
        max_value = 8,
        value     = 4,
        help      = (
            "How many document excerpts feed into each answer. "
            "Higher = more context, more tokens used."
        ),
    )
    show_sources = st.toggle(
        "Show source excerpts",
        value = True,
        help  = "Display which parts of the document were used for each answer",
    )

    st.markdown("---")

    # ── Clear chat ────────────────────────────────────────────────────────
    if st.button("🗑️  Clear conversation", use_container_width=True):
        st.session_state.messages         = []
        st.session_state.pending_question = None
        st.rerun()

    st.markdown("---")
    st.caption(
        "Powered by Groq · LLaMA 3 70B · MiniLM · ChromaDB\n\n"
        "Answers are grounded in the uploaded document only."
    )


# ══════════════════════════════════════════════════════════════════════════════
# MAIN CONTENT — NO DOCUMENT LOADED
# ══════════════════════════════════════════════════════════════════════════════
if not st.session_state.collection_name:
    st.markdown("""
    <div class="welcome-box">
        <div class="welcome-icon">📋</div>
        <div class="welcome-title">No document loaded</div>
        <div class="welcome-sub">
            Upload a PDF or TXT insurance policy document from the
            left sidebar to begin.<br>
            The app will read and index your document, then let you
            ask questions in plain English.
        </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("#### Example questions you will be able to ask")
    examples = [
        ("💧", "What is the deductible for water damage claims?"),
        ("💎", "Is jewellery covered under this policy?"),
        ("🌪️", "How do I file a claim for storm damage?"),
        ("🚫", "What are the main exclusions in this policy?"),
        ("💰", "What is the maximum coverage limit for personal property?"),
        ("⏱️", "How long do I have to report a claim after an incident?"),
        ("🏠", "Does this policy cover additional living expenses?"),
        ("📝", "What documents do I need to submit with a claim?"),
    ]
    col_a, col_b = st.columns(2)
    for i, (icon, q) in enumerate(examples):
        col = col_a if i % 2 == 0 else col_b
        col.markdown(f"{icon} _{q}_")

    st.stop()   # do not render anything below this point


# ══════════════════════════════════════════════════════════════════════════════
# MAIN CONTENT — DOCUMENT LOADED
# ══════════════════════════════════════════════════════════════════════════════

# ── Document banner ───────────────────────────────────────────────────────────
info = st.session_state.doc_info
st.markdown(f"""
<div class="doc-banner">
    <span class="doc-name">📎 {info['file_name']}</span>
    &nbsp;&nbsp;<span class="status-ready">✓ Ready</span>
    <div class="doc-pills">
        <span class="doc-pill">{info['total_chunks']:,} chunks indexed</span>
        <span class="doc-pill">{info['total_chars']:,} characters</span>
        <span class="doc-pill">Top-{top_k} retrieval</span>
    </div>
</div>
""", unsafe_allow_html=True)


# ── Suggested questions (shown only on fresh chat) ────────────────────────────
SUGGESTIONS = [
    "What does this policy cover?",
    "What are the main exclusions?",
    "How do I file a claim?",
    "What are the coverage limits?",
    "What is the deductible?",
    "Does this cover water damage?",
]

if not st.session_state.messages:
    st.markdown("**Suggested questions — click to ask instantly:**")
    cols = st.columns(3)
    for idx, suggestion in enumerate(SUGGESTIONS):
        if cols[idx % 3].button(
            suggestion,
            key              = f"suggest_{idx}",
            use_container_width = True,
        ):
            st.session_state.pending_question = suggestion
            st.rerun()


# ── Render existing conversation ──────────────────────────────────────────────
for message in st.session_state.messages:
    role    = message["role"]
    content = message["content"]
    chunks  = message.get("chunks", [])

    if role == "user":
        st.markdown(f"""
        <div class="bubble-user">
            <div class="bubble-label">You</div>
            {content}
        </div>
        """, unsafe_allow_html=True)

    else:
        # Render assistant response (escape braces for f-string safety)
        safe_content = content.replace("{", "&#123;").replace("}", "&#125;")
        safe_content = safe_content.replace("\n", "<br>")
        st.markdown(f"""
        <div class="bubble-bot">
            <div class="bubble-label">🛡️ Policy Analyst</div>
            {safe_content}
        </div>
        """, unsafe_allow_html=True)

        if show_sources and chunks:
            with st.expander(
                f"📄 View {len(chunks)} source excerpt(s) used",
                expanded = False,
            ):
                for i, chunk in enumerate(chunks, start=1):
                    preview = chunk["text"][:500]
                    if len(chunk["text"]) > 500:
                        preview += "…"
                    st.markdown(f"""
                    <div class="src-card">
                        <div class="src-card-label">
                            Excerpt {i} &nbsp;·&nbsp;
                            Relevance {chunk['score']:.0%}
                        </div>
                        {preview}
                    </div>
                    """, unsafe_allow_html=True)


# ── Chat input box ────────────────────────────────────────────────────────────
typed_input = st.chat_input(
    "Ask about claims, coverage, exclusions, deductibles, limits…",
    disabled = (not st.session_state.collection_name),
)


# ── Resolve input source (typed vs button) ────────────────────────────────────
user_input = None
if typed_input:
    user_input = typed_input.strip()
elif st.session_state.pending_question:
    user_input                        = st.session_state.pending_question
    st.session_state.pending_question = None


# ══════════════════════════════════════════════════════════════════════════════
# PROCESS USER QUESTION
# ══════════════════════════════════════════════════════════════════════════════
if user_input and st.session_state.collection_name:

    # guard: no empty questions
    if not user_input.strip():
        st.stop()

    # ── Show user bubble immediately ──────────────────────────────────────
    st.markdown(f"""
    <div class="bubble-user">
        <div class="bubble-label">You</div>
        {user_input}
    </div>
    """, unsafe_allow_html=True)

    # ── Save user turn to history ─────────────────────────────────────────
    st.session_state.messages.append({
        "role"   : "user",
        "content": user_input,
    })

    # ── Retrieve relevant document chunks ─────────────────────────────────
    with st.spinner("Searching document…"):
        try:
            retrieved = retrieve_chunks(
                query           = user_input,
                collection_name = st.session_state.collection_name,
                top_k           = top_k,
            )
        except Exception as err:
            st.error(f"Retrieval failed: {err}")
            st.stop()

    # ── Build conversation history for LLM ───────────────────────────────
    # Send all previous turns EXCEPT the current one (already augmented below)
    history = [
        {"role": m["role"], "content": m["content"]}
        for m in st.session_state.messages[:-1]
    ]

    # ── Stream LLM response ───────────────────────────────────────────────
    st.markdown("""
    <div class="bubble-bot">
        <div class="bubble-label">🛡️ Policy Analyst</div>
    """, unsafe_allow_html=True)

    answer_placeholder = st.empty()
    full_answer        = ""

    try:
        for token in stream_response(
            user_question        = user_input,
            chunks               = retrieved,
            conversation_history = history,
        ):
            full_answer += token
            # show cursor while streaming
            answer_placeholder.markdown(full_answer + " ▌")

        # final render without cursor
        answer_placeholder.markdown(full_answer)

    except EnvironmentError as env_err:
        # API key not configured
        full_answer = str(env_err)
        answer_placeholder.error(full_answer)

    except Exception as err:
        full_answer = f"An error occurred while generating the response: {err}"
        answer_placeholder.error(full_answer)

    st.markdown("</div>", unsafe_allow_html=True)

    # ── Save assistant turn to history ────────────────────────────────────
    st.session_state.messages.append({
        "role"   : "assistant",
        "content": full_answer,
        "chunks" : retrieved,
    })

    # ── Show sources for this response ────────────────────────────────────
    if show_sources and retrieved:
        with st.expander(
            f"📄 View {len(retrieved)} source excerpt(s) used",
            expanded = False,
        ):
            for i, chunk in enumerate(retrieved, start=1):
                preview = chunk["text"][:500]
                if len(chunk["text"]) > 500:
                    preview += "…"
                st.markdown(f"""
                <div class="src-card">
                    <div class="src-card-label">
                        Excerpt {i} &nbsp;·&nbsp;
                        Relevance {chunk['score']:.0%}
                    </div>
                    {preview}
                </div>
                """, unsafe_allow_html=True)

    # ── Rerun to clean up state and re-render cleanly ─────────────────────
    st.rerun()
