# 🛡️ Insurance Policy Analyst

A RAG-powered Streamlit app for analysing P&C insurance documents.
Upload any policy PDF or TXT and ask questions about claims, coverage,
exclusions, deductibles and more — all answers grounded in your document.

---

## Quick Start (Windows)

### Option A — Double-click setup (easiest)

1. Double-click **`setup.bat`** — installs everything automatically
2. Open **`.env`** in Notepad and add your Groq API key
3. Double-click **`run.bat`** — starts the app
4. Open your browser and go to **`http://localhost:8501`**

### Option B — Manual setup (Command Prompt)

```cmd
REM 1. Open Command Prompt in the project folder

REM 2. Create virtual environment
python -m venv venv

REM 3. Activate it  (you must see (venv) appear)
venv\Scripts\activate

REM 4. Install packages
pip install -r requirements.txt

REM 5. Copy and configure .env
copy .env.example .env
REM  ↑ then open .env in Notepad and add your GROQ_API_KEY

REM 6. Run the app
python -m streamlit run app.py

REM 7. Open browser at http://localhost:8501
```

---

## Getting a Free Groq API Key

1. Go to **https://console.groq.com**
2. Sign up for a free account
3. Click **API Keys** → **Create API Key**
4. Copy the key and paste it into your `.env` file:
   ```
   GROQ_API_KEY=gsk_xxxxxxxxxxxxxxxxxxxxxxxx
   ```

---

## Project Files

```
insurance_rag_app\
│
├── app.py                  ← Main Streamlit UI (run this)
├── document_processor.py   ← Parse, chunk, embed, store, retrieve
├── chat_engine.py          ← Groq LLM calls and RAG prompt builder
│
├── setup.bat               ← One-click Windows setup script
├── run.bat                 ← One-click Windows launcher
│
├── requirements.txt        ← Python package list
├── .env.example            ← API key template
├── .env                    ← Your actual API key (never share this)
├── .gitignore
└── README.md
```

---

## How It Works

```
UPLOAD:
  PDF or TXT
      ↓
  Parse text (PyPDF)
      ↓
  Split into 400-word chunks with 50-word overlap
      ↓
  Embed each chunk (MiniLM — runs locally, free)
      ↓
  Store in ChromaDB (local vector database)

QUESTION:
  You type a question
      ↓
  Question embedded with same MiniLM model
      ↓
  Cosine similarity search → top-4 most relevant chunks
      ↓
  Chunks + question sent to Groq (LLaMA 3 70B)
      ↓
  Answer streamed back to screen
      ↓
  Source excerpts shown below the answer
```

---

## Settings

| Setting | Description | Default |
|---|---|---|
| Chunks to retrieve | How many document sections feed into each answer | 4 |
| Show source excerpts | Display which parts of the document were used | On |

---

## Example Questions

- What does this policy cover?
- What are the main exclusions?
- What is the deductible for water damage?
- How do I file a claim?
- What is the coverage limit for personal property?
- How long do I have to report a claim?
- Is jewellery covered under this policy?
- Does this policy cover additional living expenses?

---

## Troubleshooting (Windows)

| Problem | Fix |
|---|---|
| App hangs on "Connecting" | Open browser manually at `http://localhost:8501` |
| `ModuleNotFoundError` | Run `venv\Scripts\activate` then `pip install -r requirements.txt` |
| `GROQ_API_KEY not found` | Open `.env` and add your key |
| Port 8501 in use | Run `python -m streamlit run app.py --server.port=8080` |
| PDF shows no text | Your PDF may be image-based (scanned). Use a text PDF |
| Slow on first run | MiniLM model downloads ~90 MB once. Subsequent runs are fast |

---

## Tech Stack

| Component | Technology |
|---|---|
| UI | Streamlit |
| Document parser | PyPDF |
| Chunking | Custom word-level sliding window |
| Embedding model | all-MiniLM-L6-v2 (local, free) |
| Vector database | ChromaDB (local, persisted to ./chroma_db) |
| LLM | LLaMA 3 70B via Groq API |
| Temperature | 0.1 (factual, grounded) |
