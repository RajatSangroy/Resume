"""
document_processor.py
─────────────────────
Handles all document ingestion for the Insurance Policy Analyst.

Pipeline:
    1. Parse  — extract raw text from PDF or TXT
    2. Chunk  — split into overlapping windows
    3. Embed  — convert chunks to vectors using MiniLM
    4. Store  — save vectors + text in ChromaDB

Also handles retrieval:
    5. Search — embed query, find top-k similar chunks
"""

import os
import io
import hashlib

import chromadb
from pypdf import PdfReader
from sentence_transformers import SentenceTransformer


# ── Configuration ──────────────────────────────────────────────────────────────
CHUNK_SIZE    = 400     # words per chunk (smaller = more precise retrieval)
CHUNK_OVERLAP = 50      # words shared between consecutive chunks
EMBED_MODEL   = "all-MiniLM-L6-v2"   # fast, free, runs locally
CHROMA_PATH   = "./chroma_db"         # persisted to disk


# ── Singletons (loaded once, reused) ──────────────────────────────────────────
_embed_model   = None
_chroma_client = None


def get_embed_model() -> SentenceTransformer:
    """Load the embedding model once and cache it."""
    global _embed_model
    if _embed_model is None:
        _embed_model = SentenceTransformer(EMBED_MODEL)
    return _embed_model


def get_chroma_client() -> chromadb.PersistentClient:
    """Create the ChromaDB client once and cache it."""
    global _chroma_client
    if _chroma_client is None:
        os.makedirs(CHROMA_PATH, exist_ok=True)
        _chroma_client = chromadb.PersistentClient(path=CHROMA_PATH)
    return _chroma_client


# ══════════════════════════════════════════════════════════════════════════════
# STEP 1 — PARSING
# ══════════════════════════════════════════════════════════════════════════════

def parse_pdf(file_bytes: bytes) -> str:
    """Extract text from a PDF file, page by page."""
    reader = PdfReader(io.BytesIO(file_bytes))
    pages  = []
    for page_num, page in enumerate(reader.pages, start=1):
        text = page.extract_text()
        if text and text.strip():
            pages.append(f"[Page {page_num}]\n{text.strip()}")
    if not pages:
        raise ValueError(
            "Could not extract any text from this PDF. "
            "It may be a scanned image PDF. "
            "Please use a text-based PDF."
        )
    return "\n\n".join(pages)


def parse_txt(file_bytes: bytes) -> str:
    """Decode a plain text file."""
    try:
        return file_bytes.decode("utf-8")
    except UnicodeDecodeError:
        return file_bytes.decode("latin-1", errors="ignore")


def parse_document(file_bytes: bytes, file_name: str) -> str:
    """Route to the right parser based on file extension."""
    extension = file_name.rsplit(".", 1)[-1].lower()
    if extension == "pdf":
        return parse_pdf(file_bytes)
    elif extension == "txt":
        return parse_txt(file_bytes)
    else:
        raise ValueError(
            f"Unsupported file type: .{extension}. "
            "Please upload a PDF or TXT file."
        )


# ══════════════════════════════════════════════════════════════════════════════
# STEP 2 — CHUNKING
# ══════════════════════════════════════════════════════════════════════════════

def split_into_chunks(
    text    : str,
    size    : int = CHUNK_SIZE,
    overlap : int = CHUNK_OVERLAP
) -> list:
    """
    Split text into overlapping word-level chunks.

    Why overlap?
    Without overlap, a sentence split across two chunks
    loses context at the boundary. Overlap ensures every
    idea has surrounding context in at least one chunk.

    Returns a list of chunk strings.
    """
    words  = text.split()
    chunks = []
    start  = 0

    while start < len(words):
        end   = min(start + size, len(words))
        chunk = " ".join(words[start:end])
        if chunk.strip():
            chunks.append(chunk)
        if end >= len(words):
            break
        start = end - overlap   # slide back to create overlap

    return chunks


# ══════════════════════════════════════════════════════════════════════════════
# STEP 3 + 4 — EMBED + STORE
# ══════════════════════════════════════════════════════════════════════════════

def make_collection_name(file_name: str) -> str:
    """
    ChromaDB collection names must be:
    - 3 to 63 characters
    - Alphanumeric + hyphens only
    - No consecutive hyphens
    """
    clean = "".join(
        c if c.isalnum() else "-"
        for c in file_name.lower()
    ).strip("-")[:48]

    # append short hash to prevent collisions between similarly named files
    h = hashlib.md5(file_name.encode()).hexdigest()[:8]
    return f"{clean}-{h}"


def ingest_document(file_bytes: bytes, file_name: str) -> dict:
    """
    Full ingestion pipeline: parse → chunk → embed → store.

    Returns a summary dict consumed by the Streamlit UI.
    """
    # 1. Parse
    raw_text = parse_document(file_bytes, file_name)
    if not raw_text.strip():
        raise ValueError("Document appears to be empty after parsing.")

    # 2. Chunk
    chunks = split_into_chunks(raw_text)
    if not chunks:
        raise ValueError("Could not split document into chunks.")

    # 3. Embed
    model      = get_embed_model()
    embeddings = model.encode(
        chunks,
        batch_size         = 32,
        show_progress_bar  = False,
        convert_to_list    = True,
    )

    # 4. Store in ChromaDB
    client       = get_chroma_client()
    col_name     = make_collection_name(file_name)

    # delete existing collection for this file so re-upload works cleanly
    try:
        client.delete_collection(col_name)
    except Exception:
        pass

    collection = client.create_collection(
        name     = col_name,
        metadata = {"source": file_name},
    )

    collection.add(
        ids        = [f"chunk-{i}" for i in range(len(chunks))],
        embeddings = embeddings,
        documents  = chunks,
        metadatas  = [
            {"chunk_index": i, "source": file_name}
            for i in range(len(chunks))
        ],
    )

    return {
        "collection_name" : col_name,
        "file_name"       : file_name,
        "total_chars"     : len(raw_text),
        "total_chunks"    : len(chunks),
        "chunk_size"      : CHUNK_SIZE,
        "overlap"         : CHUNK_OVERLAP,
        "embed_model"     : EMBED_MODEL,
    }


# ══════════════════════════════════════════════════════════════════════════════
# STEP 5 — RETRIEVAL
# ══════════════════════════════════════════════════════════════════════════════

def retrieve_chunks(
    query           : str,
    collection_name : str,
    top_k           : int = 4,
) -> list:
    """
    Semantic search:
      1. Embed the user query
      2. Find top-k chunks with highest cosine similarity
      3. Return list of {text, chunk_index, score}

    Score of 1.0 = perfect match, 0.0 = completely unrelated.
    """
    model           = get_embed_model()
    query_embedding = model.encode(query, convert_to_list=True)

    client     = get_chroma_client()
    collection = client.get_collection(collection_name)

    results = collection.query(
        query_embeddings = [query_embedding],
        n_results        = top_k,
        include          = ["documents", "metadatas", "distances"],
    )

    chunks = []
    for doc, meta, distance in zip(
        results["documents"][0],
        results["metadatas"][0],
        results["distances"][0],
    ):
        # ChromaDB returns L2 distance; convert to 0-1 similarity
        similarity = max(0.0, 1.0 - distance / 2.0)
        chunks.append({
            "text"        : doc,
            "chunk_index" : meta.get("chunk_index", 0),
            "score"       : round(similarity, 3),
        })

    # sort highest similarity first
    chunks.sort(key=lambda x: x["score"], reverse=True)
    return chunks
